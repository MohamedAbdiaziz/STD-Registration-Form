﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STD_Registration
{
    public partial class STDRegisterPage : System.Web.UI.Page
    {
     
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
    }

}